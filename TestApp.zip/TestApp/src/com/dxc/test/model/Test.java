package com.dxc.test.model;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
	}

}
